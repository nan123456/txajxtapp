
url='http://127.0.0.1:8081/hxadmin2/hxajxt/';
//url='http://service.jsjdw.org.cn:8080/hxadmin/hxajxt/';
